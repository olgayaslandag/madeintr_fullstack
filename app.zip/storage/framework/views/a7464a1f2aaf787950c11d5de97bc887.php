<?php if (isset($component)) { $__componentOriginalc1313589dbbcd9696e6695540cbeed4c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc1313589dbbcd9696e6695540cbeed4c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.client-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('client-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <div class="home-area text-center">
            <h1 class="fw-bold">Products & More</h1>
            <p>Discover the excellent products in Türkiye</p>
            <ul class="list-inline">
                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-inline-item">
                    <a href=""><?php echo e($tag->name); ?></a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        <div class="map my-5">
            <?php echo $__env->make('client.home.map', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc1313589dbbcd9696e6695540cbeed4c)): ?>
<?php $attributes = $__attributesOriginalc1313589dbbcd9696e6695540cbeed4c; ?>
<?php unset($__attributesOriginalc1313589dbbcd9696e6695540cbeed4c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc1313589dbbcd9696e6695540cbeed4c)): ?>
<?php $component = $__componentOriginalc1313589dbbcd9696e6695540cbeed4c; ?>
<?php unset($__componentOriginalc1313589dbbcd9696e6695540cbeed4c); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Olgay\Desktop\projeler\MadeInTR\madeintr_fullstack\resources\views/client/home/home.blade.php ENDPATH**/ ?>