<?php if (isset($component)) { $__componentOriginalc1313589dbbcd9696e6695540cbeed4c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc1313589dbbcd9696e6695540cbeed4c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.client-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('client-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <div class="text-center mb-5">
            <ul class="link-letters list-inline mb-0">
                <li class="list-inline-item">
                    <a href="" class="text-danger text-decoration-none fw-bold">
                        #
                    </a>
                </li>
                <?php $__currentLoopData = $letters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $letter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-inline-item">
                    <a href="" class="text-danger text-decoration-none fw-bold">
                        <?php echo e($letter); ?>

                    </a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>

    <div class="container">
        <ul class="list-unstyled">
            <li class="mb-4">
                <h3 class="fw-bold h4">#</h3>
                <ul class="list-inline link-letters border-0 p-0">
                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(ctype_digit(mb_substr($company->name, 0, 1))): ?>
                        <li class="list-inline-item">
                            <a href="" class="text-danger text-decoration-none"><?php echo e($company->name); ?></a>
                        </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </li>
            </ul>
            <?php $__currentLoopData = $letters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $letter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="mb-4">
                <h3 class="fw-bold h4"><?php echo e($letter); ?></h3>
                <ul class="list-inline link-letters border-0 p-0">
                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(strtolower(mb_substr($company->name, 0, 1)) === $letter): ?>
                        <li class="list-inline-item">
                            <a href="<?php echo e(route('company.get', $company->id)); ?>" class="text-danger text-decoration-none"><?php echo e($company->name); ?></a>
                        </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc1313589dbbcd9696e6695540cbeed4c)): ?>
<?php $attributes = $__attributesOriginalc1313589dbbcd9696e6695540cbeed4c; ?>
<?php unset($__attributesOriginalc1313589dbbcd9696e6695540cbeed4c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc1313589dbbcd9696e6695540cbeed4c)): ?>
<?php $component = $__componentOriginalc1313589dbbcd9696e6695540cbeed4c; ?>
<?php unset($__componentOriginalc1313589dbbcd9696e6695540cbeed4c); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Olgay\Desktop\projeler\MadeInTR\madeintr_fullstack\resources\views/client/company/companies.blade.php ENDPATH**/ ?>