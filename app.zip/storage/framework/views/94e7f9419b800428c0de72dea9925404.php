<form action="<?php echo e(isset($item) ? route('admin.company.store', $item->id) : route('admin.company.store')); ?>"
      method="POST"
      enctype="multipart/form-data"
      autocomplete="off">
    <?php echo csrf_field(); ?>


    <!-- Ünvan -->
    <div class="mb-3">
        <label for="name" class="<?php echo e($errors->has('name') ? 'text-danger' : ''); ?>">Ünvan</label>
        <input type="text"
               class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>"
               name="name"
               id="name"
               placeholder="Firma ünvanı"
               value="<?php echo e(old('name', $item->name ?? '')); ?>">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <!-- Website -->
    <div class="mb-3">
        <label for="webpage" class="<?php echo e($errors->has('webpage') ? 'text-danger' : ''); ?>">Website</label>
        <input type="text"
               class="form-control <?php echo e($errors->has('webpage') ? 'is-invalid' : ''); ?>"
               name="webpage"
               id="webpage"
               placeholder="Firma internet sitesi"
               value="<?php echo e(old('webpage', $item->webpage ?? '')); ?>">
        <?php $__errorArgs = ['webpage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <!-- Açıklama -->
    <div class="mb-3">
        <label for="desc" class="<?php echo e($errors->has('desc') ? 'text-danger' : ''); ?>">Açıklama</label>
        <textarea class="form-control <?php echo e($errors->has('desc') ? 'is-invalid' : ''); ?>"
                  name="desc"
                  id="desc"
                  placeholder="Firma açıklama"><?php echo e(old('desc', $item->desc ?? '')); ?></textarea>
        <?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <!-- Şehir -->
    <div class="mb-3">
        <label for="city_id" class="<?php echo e($errors->has('city_id') ? 'text-danger' : ''); ?>">Şehir</label>
        <select class="form-select <?php echo e($errors->has('city_id') ? 'is-invalid' : ''); ?>"
                name="city_id"
                id="city_name">
            <option value="">Seçim Yapın...</option>
            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($city->id); ?>"
                    <?php echo e(old('city_id', $item->city_id ?? '') == $city->id ? 'selected' : ''); ?>>
                    <?php echo e($city->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['city_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <!-- Logo -->
    <div class="mb-3">

        <label for="logo" class="<?php echo e($errors->has('logo') ? 'text-danger' : ''); ?>">Firma logosu</label>
        <input type="file"
               class="form-control <?php echo e($errors->has('logo') ? 'is-invalid' : ''); ?>"
               name="logo"
               id="logo"
               placeholder="Firma logosu">
        <div class="logo-content">
        <?php if(isset($item) && $item->logo): ?>
            <a href="<?php echo e(asset($item->logo?->path)); ?>" target="_blank" class="company-logo-link btn btn-link text-dark text-decoration-none ps-0">
                <img src="<?php echo e(asset($item->logo?->path)); ?>" class="logo-img" alt="Firma logosu">
            </a>
            <button type="button" class="btn btn-sm btn-danger remove-file">Sil</button>
        <?php endif; ?>
        </div>
        <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <!-- Franchising -->
    <div class="mb-3">
        <label for="franchising" class="<?php echo e($errors->has('franchising') ? 'text-danger' : ''); ?>">Franchising</label>
        <select class="form-select <?php echo e($errors->has('franchising') ? 'is-invalid' : ''); ?>"
                name="franchising"
                id="franchising">
            <option value="">Seçim Yapın...</option>
            <option value="0" <?php echo e(old('franchising', $item->franchising ?? '') == 0 ? 'selected' : ''); ?>>Hayır</option>
            <option value="1" <?php echo e(old('franchising', $item->franchising ?? '') == 1 ? 'selected' : ''); ?>>Evet</option>
        </select>
        <?php $__errorArgs = ['franchising'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <!-- Tag Input -->
    <div class="mb-3">
        <?php echo $__env->make('admin.company.tag-input', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <!-- Hidden User ID -->
    <input type="hidden" name="user_id" value="<?php echo e(auth()->id()); ?>">

    <!-- Submit Button -->
    <button type="submit" class="btn btn-primary w-100 mt-3">
        <?php echo e(isset($item) ? 'Güncelle' : 'Kaydet'); ?>

    </button>
</form>
<?php /**PATH C:\Users\Olgay\Desktop\projeler\MadeInTR\madeintr_fullstack\resources\views/admin/company/company-form.blade.php ENDPATH**/ ?>