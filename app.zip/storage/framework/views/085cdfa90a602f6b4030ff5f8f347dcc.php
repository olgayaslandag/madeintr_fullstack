<?php if (isset($component)) { $__componentOriginalc1313589dbbcd9696e6695540cbeed4c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc1313589dbbcd9696e6695540cbeed4c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.client-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('client-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <h1 class="fw-bold my-5 text-center"><?php echo e($tag->name); ?></h1>

        <div>
            <ul class="list-unstyled companies">
                <?php $__currentLoopData = $tag->companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(route('company.get', $item->id)); ?>" class="text-decoration-none text-dark">
                            <div class="d-flex">
                                <figure class="m-0">
                                    <img src="/<?php echo e($item->logo->path); ?>" alt="<?php echo e($item->name); ?>" width="150" class="me-3">
                                </figure>
                                <div>
                                    <table class="table table-sm table-borderless company-detail">
                                        <tr>
                                            <td colspan="2">
                                                <h2 class="h4"><?php echo e($item->name); ?></h2>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>Webpage:</th>
                                            <td><?php echo e($item->webpage); ?></td>
                                        </tr>
                                        <tr>
                                            <th>City:</th>
                                            <td><?php echo e($item->city->name); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Franchising:</th>
                                            <td><?php echo e($item->franchising ? 'yes' : 'no'); ?></td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </a>
                    </li>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc1313589dbbcd9696e6695540cbeed4c)): ?>
<?php $attributes = $__attributesOriginalc1313589dbbcd9696e6695540cbeed4c; ?>
<?php unset($__attributesOriginalc1313589dbbcd9696e6695540cbeed4c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc1313589dbbcd9696e6695540cbeed4c)): ?>
<?php $component = $__componentOriginalc1313589dbbcd9696e6695540cbeed4c; ?>
<?php unset($__componentOriginalc1313589dbbcd9696e6695540cbeed4c); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Olgay\Desktop\projeler\MadeInTR\madeintr_fullstack\resources\views/client/tag/tag.blade.php ENDPATH**/ ?>