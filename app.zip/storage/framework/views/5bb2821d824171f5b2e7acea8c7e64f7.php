<div class="offcanvas offcanvas-end" tabindex="-1" id="corporateForm" aria-labelledby="corporateFormLabel">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="corporateFormLabel">Şirket Formu</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
        <div>
            <?php echo $__env->make('admin.company.company-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Olgay\Desktop\projeler\MadeInTR\madeintr_fullstack\resources\views/admin/company/company-modal.blade.php ENDPATH**/ ?>