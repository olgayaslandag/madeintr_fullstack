<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="header-title">
        <div class="float-start">
            <h1 class="h5">Şirket Yönetimi</h1>
        </div>
        <div class="float-end">
            <a href="<?php echo e(route('admin.company.create')); ?>" class="btn btn-outline-secondary">
                <span class="me-2">Yeni</span>
                <i class="fa-solid fa-plus"></i>
            </a>
        </div>
    </div>

    <table class="table table-hover d-table">
        <thead>
        <tr>
            <th scope="col" width="50">#</th>
            <th scope="col">Ünvan</th>
            <th scope="col">Etiketler</th>
            <th scope="col">Açıklama</th>
            <th scope="col">Franchising</th>
            <th scope="col">Logo</th>
            <th scope="col" width="150">Şehir</th>
            <th scope="col" width="50"></th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td scope="row"><?php echo e($company->id); ?></td>
                <td><?php echo e($company->name); ?></td>
                <td>
                    <?php $__currentLoopData = $company->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="badge badge-sm text-bg-secondary me-1"><?php echo e($tag->name); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td><?php echo e($company->desc); ?></td>
                <td>
                    <?php echo $company->franchising
                        ? '<i class="fa-solid fa-check text-success"></i>'
                        : '<i class="fa-solid fa-xmark text-danger"></i>'; ?>

                </td>

                <td>
                    <?php if(optional($company->logo)->path): ?>
                        <a href="<?php echo e(asset(optional($company->logo)->path)); ?>" class="badge text-bg-primary text-decoration-none" target="_blank">Link</a>
                    <?php else: ?>
                        <span class="badge text-bg-secondary">Yok</span>
                    <?php endif; ?>
                </td>

                <td><?php echo e(optional($company->city)->name ?? '-'); ?></td>

                <td>
                    <div class="btn-group" role="group">
                        <div class="me-1">
                        <a href="<?php echo e(route('admin.company.edit', ['id' => $company->id])); ?>" class="btn btn-sm btn-secondary">
                            <i class="fa-solid fa-pen"></i>
                        </a>
                        </div>
                        <form action="<?php echo e(route('admin.company.delete', $company->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <input type="hidden" name="id" value="<?php echo e($company->id); ?>">
                            <button type="submit" class="btn btn-sm btn-danger sil">
                                <i class="fa-solid fa-trash"></i>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Olgay\Desktop\projeler\MadeInTR\madeintr_fullstack\resources\views/admin/company/companies.blade.php ENDPATH**/ ?>