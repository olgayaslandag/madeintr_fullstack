<?php if (isset($component)) { $__componentOriginalc1313589dbbcd9696e6695540cbeed4c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc1313589dbbcd9696e6695540cbeed4c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.client-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('client-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc1313589dbbcd9696e6695540cbeed4c)): ?>
<?php $attributes = $__attributesOriginalc1313589dbbcd9696e6695540cbeed4c; ?>
<?php unset($__attributesOriginalc1313589dbbcd9696e6695540cbeed4c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc1313589dbbcd9696e6695540cbeed4c)): ?>
<?php $component = $__componentOriginalc1313589dbbcd9696e6695540cbeed4c; ?>
<?php unset($__componentOriginalc1313589dbbcd9696e6695540cbeed4c); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Olgay\Desktop\projeler\MadeInTR\madeintr_fullstack\resources\views/client/company/company.blade.php ENDPATH**/ ?>