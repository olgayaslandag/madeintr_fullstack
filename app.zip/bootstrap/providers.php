<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\RepositoryProvider::class,
    App\Providers\RouteServiceProvider::class,
    App\Providers\TagsProvider::class,
];
