<x-admin-layout>
    <div>
        <div id="chart_div"></div>
      </div>
</x-admin-layout>
